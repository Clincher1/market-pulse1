# 07. Цепочка данных: источник → API → сервер → обработка → компонент → экран

Сборка `e4939ae`. Пути и строки — по этому коммиту. Показаны все цепочки, которые формируют числа на экране.

---

## 0. Общая схема

```
                ┌─────────────── внешние источники ───────────────┐
                │ CBR (XML / SOAP) · MOEX ISS · FRED/EIA · ECB    │
                │ Kraken · Twelve Data · RSS 20+ лент             │
                └───────┬───────────────┬────────────────┬────────┘
                        │               │                │
        serverless Vercel API      Supabase Edge      Supabase Edge
        api/russia-insights.js     update-assets      update-news-v2
        api/russia-history.js      update-tension     update-forecasts
                │                       │            snapshot-morning
                ▼                       ▼                │
        HTTP JSON (s-maxage)      таблицы-кэши:           ▼
                │                 cached_assets      cached_news / cached_tension
                │                 cached_tension     daily_snapshots / forecast_*
                │                       │
                └──────────► браузер (React) ◄──────────┘
                                   │
                    components/* → числа на экране
```

Кэшей три слоя: **Vercel edge** (`s-maxage` на ответах API), **Supabase-таблицы** (`cached_*`, пишутся кроном), **браузер** (опрос раз в N секунд, `src/lib/polling.ts`).

---

## 1. Российский контур: `/api/russia-insights`

**Файл:** `api/russia-insights.js`, обработчик — строка 826.

| Шаг | Что происходит | Строки |
|---|---|---|
| 1 | Проверка метода (GET/HEAD, иначе 405) | 827–831 |
| 2 | Параллельный запуск 12 рыночных задач и 20+ RSS через `Promise.allSettled` | 834–870 |
| 3 | Каждая задача — отдельная функция; ошибка одной не рушит остальные | 872–878 |
| 4 | Заголовки сортируются по времени, дедуплицируются по заголовку и ссылке, обрезаются до 18 | 884–899 |
| 5 | Кэш: при ошибках `s-maxage=60, stale-while-revalidate=120`, без ошибок `s-maxage=300, swr=900` | 903–908 |

**Функции и поля**

| Индикатор | Функция (строка) | Запрос | Поля |
|---|---|---|---|
| Курсы ЦБ | `fetchCbrIndicator` (174) | `cbr.ru/scripts/XML_dynamic.asp?date_req1…&VAL_NM_RQ=<код>` | `Record/Value`, `Record/@Date` |
| IMOEX, RGBI | `fetchMoexIndex` (548) + `fetchMoexPreviousClose` (525) | `iss.moex.com/iss/engines/stock/markets/index/securities/<SECID>.json?iss.meta=off` + `…/history/…` | `marketdata/CURRENTVALUE`, `marketdata/SYSTIME`, `history/CLOSE`, `history/TRADEDATE` |
| Юань на Мосбирже | `fetchMoexCny` (710) + `fetchCurrencyHistory` (534) + `pickQuoteBase` (511) | `…/currency/markets/selt/securities/CNYRUB_TOM.json` + history | `marketdata/LAST`, `history/CLOSE/BOARDID` |
| Золото | `fetchMoexGold` (596) + те же помощники, `boardId='CETS'` | `…/securities/GLDRUB_TOM.json` + history | `marketdata/LAST`, `securities/PREVPRICE`, `history/CLOSE` |
| Ключевая ставка | `fetchCbrKeyRate` (288), разбор `parseKeyRateXml` (220) | POST SOAP `DailyInfo.asmx` | `KR/DT`, `KR/Rate` |
| RUONIA | `fetchRuonia` (345) | POST SOAP (`api/_shared/cbrRuonia.js`) | `Ro/DATE`, `Ro/RUONIA`, объём |
| Резервы | `fetchReserves` (388) | POST SOAP (`api/_shared/cbrReserves.js`) | `MRRF7D/Date`, `InternationalReserves` |
| Кривая ОФЗ | `fetchMoexOfz10y` (420) → `extractCurve` (274) → `pickOfz10y` (253) | `iss.moex.com/iss/engines/stock/zcyc.json?iss.meta=off` | строка срока, колонки `y*`, `tradedate`, `tradetime` |
| Инфляция | `fetchInflation` (665) | HTML `cbr.ru/hd_base/infl/` и запасная выгрузка `Queries/UniDbQuery/DownloadExcel/132934` | таблица месяцев: инфляция г/г, ключевая ставка, цель |

**Ошибки:** каждый сбой попадает в массив `errors` с человекочитаемой меткой («Ключевая ставка ЦБ: таймаут»), индикатор не попадает в ответ, а `selfcheck` ловит пропажу по id.

**Дата:** для ЦБ — дата записи из ответа; для Мосбиржи — `SYSTIME` рынка (время источника, не время записи в кэш); для SOAP — дата записи; для инфляции — последний день месяца (`monthEndDate`).

**Передача в UI:** `src/data/russiaInsights.ts` (`fetchRussiaInsights`, типы) → `src/components/RussiaBusiness.tsx` (`MarketTile`, `formatIndicatorValue`, `formatAsOf`, `hasCloseBase`) → `src/components/RussiaHistory.tsx`, `src/components/OfzCurve.tsx`.

## 2. История: `/api/russia-history`

**Файл:** `api/russia-history.js`, обработчик — строка 382. Окно `HISTORY_DAYS = 92` (строка 20). Кэш `s-maxage=1800, swr=900` (строка 429).

| Ряд | Функция (строка) | Источник | Что читается |
|---|---|---|---|
| IMOEX, RGBI | `fetchMoexIndexHistory` (261) + `parseIssHistory` (241) | `iss.moex.com/iss/history/engines/stock/markets/index/securities/<SECID>.json` | `TRADEDATE`, `CLOSE` |
| USD/RUB | `fetchCbrHistory` (271) + `parseCbrDynamicXml` (137) | `cbr.ru/scripts/XML_dynamic.asp` | `Record/@Date`, `Value/Nominal` |
| RUONIA | `fetchCbrHistory` | SOAP | `Ro` |
| Резервы | `fetchCbrHistory` | SOAP `mrrf7DXML` | `MRRF7D` |
| Ключевая ставка | `fetchKeyRateHistory` (283) + `buildKeyRateSteps` (177) | SOAP `KeyRate` | `KR/DT`, `Rate` — превращается в ступени |

**Правила:** линия требует ≥2 точек, ступень — ≥1 (ставка может не меняться всё окно); иначе ряд **не рисуется** и причина уходит в `errors` (строки 398–414). Ничего не интерполируется и не заполняется.

**Передача в UI:** `src/data/russiaHistory.ts` → `src/components/RussiaHistory.tsx`. Ось Y строится по круглым отметкам из данных (`src/lib/chartAxis.ts`), подписи дат — начала месяцев и края окна.

## 3. Мировые активы: Supabase `cached_assets`

**Писатель:** `supabase/functions/update-assets/index.ts` (крон `*/5 * * * *`).

| Актив | Функция (строка) | Endpoint | Поля |
|---|---|---|---|
| S&P 500 | `fetchSp500` (236) | `fred.stlouisfed.org/graph/fredgraph.csv?id=SP500&cosd=…` | последняя строка CSV |
| Brent | `fetchBrent` (250) | то же, `id=DCOILBRENTEU` | последняя строка CSV |
| USD/EUR | `fetchUsdEur` (264) | `ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml` | курс USD, инвертируется в USD/EUR |
| BTC | `fetchBtc` (289) | `api.Kraken.com/0/public/OHLC?pair=XBTUSD&interval=1440` | `result.XXBTZUSD[][4]` |
| Gold спот | `fetchGold` (320) | `api.twelvedata.com/quote?symbol=XAU/USD` + `time_series` | `close`, `percent_change`, `timestamp` |

**Запись:** `buildRow` (180–215) считает изменение, проверяет `LIMITS` (51–57), округляет до 4 знаков, кладёт `as_of` — дату наблюдения источника, отдельно от `updated_at` — времени записи. Колонка `as_of` появилась миграцией `20261030120000_cached_assets_as_of.sql`; функция умеет работать и без неё (`hasAsOfColumn`, 385–395), тогда дата наблюдения отсутствует, и плитка печатает «обновлено HH:MM МСК».

**Чтение:** `src/data/liveAssets.ts` → `src/hooks/useLiveAssets.ts` (слияние с пустыми заготовками и список `fallbackAssetIds`) → `src/components/MarketHeatmap.tsx`, `src/components/KeyAssets.tsx`, `src/components/BusinessMoney.tsx`.

## 4. Новости

**Писатель:** `supabase/functions/update-news-v2/index.ts` (крон `*/15 * * * *`): RSS 20+ лент → разбор → дедупликация → классификация (правила; при наличии ключа — `GEMINI_API_KEY`, `GEMINI_MODEL`).
**Чтение:** `src/data/liveNews.ts` → `src/hooks/useLiveNews.ts` → `src/components/NewsFeed.tsx`.
**Российские заголовки** на странице «Россия» тянутся отдельно, прямо из RSS в `api/russia-insights.js:24–60` и `fetchRss` (813), без классификации — только источник, время и ссылка.

## 5. Напряжённость

**Писатель:** `supabase/functions/update-tension/index.ts` (крон `*/15 * * * *`), формула — `04_CALCULATIONS_AUDIT.md` §7. Пишет `cached_tension` (+ `history_stats` из миграции `20261027140000`).
**Чтение:** `src/data/liveTension.ts` → `src/components/TensionScale.tsx`.

## 6. Прогнозы и журнал проверок

**Писатель:** `write-forecasts-v2-shadow` (крон `45 5 * * *`) — создаёт прогноз из событий и пишет `pending` в `forecast_outcomes_v2`.
**Оценщик:** `evaluate-forecasts-v2-shadow` (крон `50 5,17 * * *`) — по `asset_price_history_v1` считает исход, доходность, аномальность и Брайер.
**Чтение:** `src/data/liveForecasts.ts` (в том числе пересчёт вероятности из `shareOnArrow`, строка 173) → `src/components/Forecasts.tsx`; `src/components/MarketMemory.tsx` читает публичные view из миграции `20261022203000`.

## 7. Паспорт дня

**Писатель:** `snapshot-morning` (крон `0 4 * * *` = 07:00 МСК), `resolution=ignore-duplicates`.
**Чтение:** `src/data/dailySnapshots.ts`, `src/data/dailyPassports.ts` → `src/components/DailyPassport.tsx`.

## 8. Самопроверка

**Писатель:** `selfcheck` (крон `25 * * * *`) — 20 проверок, пишет `site_health`.
**Чтение:** `src/components/SystemStatus.tsx` и страница статуса.
**Прунинг:** `site-health-prune` (крон `40 3 * * *`).

## 9. Где в цепочке что можно подменить

| Точка | Что произойдёт при сбое | Кто заметит |
|---|---|---|
| Источник отдал 200 с мусором | парсеры бросают исключение (проверки на `Number.isFinite`, правдоподобные диапазоны), индикатор исчезает | `selfcheck` (по id), `errors[]` на странице |
| Источник отдал правдоподобную, но чужую площадку | защищает `boardId` фильтр (`03_FAKE_DATA_AUDIT.md`, §2) | тест `tests/cbr-inflation-gold.test.mjs` |
| Кэш Supabase устарел | плитка печатает дату наблюдения источника, `as_of`; снимок дня не перезаписывается | `assets_fresh` (45 минут), плашка «нет свежей цены» |
| Сеть до источника недоступна | ответ 200 без индикатора + `errors`, короткий кэш 60 с, чтобы восстановиться за минуту | `selfcheck`, Sentry |
| Фронт не смог прочитать Supabase | пустые плитки с «—» и плашкой, без выдуманных чисел | `isFallback` в трёх местах |
