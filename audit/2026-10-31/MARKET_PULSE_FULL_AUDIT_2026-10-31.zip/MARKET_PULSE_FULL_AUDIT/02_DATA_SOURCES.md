# 02. Источники данных Market Pulse

**Дата аудита:** 2026-10-31  
**Сборка:** git e4939ae, prod https://market-pulse1-eta.vercel.app  
**Снимок:** 2026-10-31 17:46-17:50 МСК

**Метод.** Values below were read from the project's own API/cache and, where noted, from the upstream source captured during this audit (folder 06_API_RESPONSES). verification_status follows the three-state rule of the audit brief: VERIFIED / INCORRECT / UNVERIFIED.

**Как читать изменение.** display_change_percent is a percent change of the price against display_comparison_date, except where unit is п.п. (percentage points against the previous published value). Percent of a percent is never used.

Машинночитаемая версия: `02_DATA_SOURCES.json`.

## Сводная таблица

| # | Показатель | Значение | Ед. | Изменение | Дата показателя | Дата сравнения | Источник | Статус |
|---|---|---|---|---|---|---|---|---|
| 1 | USD/RUB, официальный курс ЦБ | 80.5573 | RUB | -0.147 % | 2026-10-31 | 2026-10-30 | Банк России | VERIFIED |
| 2 | EUR/RUB, официальный курс ЦБ | 89.6603 | RUB | -0.174 % | 2026-10-31 | 2026-10-30 | Банк России | VERIFIED |
| 3 | CNY/RUB, официальный курс ЦБ | 12.0873 | RUB | +0.024 % | 2026-10-31 | 2026-10-30 | Банк России | VERIFIED |
| 4 | IMOEX, индекс МосБиржи | 2511.43 | points | +0.09 % | 2026-10-31T17:46:35+03:00 | 2026-10-30 | Мосбиржа ISS | VERIFIED |
| 5 | RGBI, индекс гособлигаций | 112.48 | points | +0.062 % | 2026-10-31T17:46:31+03:00 | 2026-10-30 | Мосбиржа ISS | UNVERIFIED |
| 6 | CNY/RUB, юань на Мосбирже (CNYRUB_TOM) | 12.0715 | RUB | -1.057 % | 2026-10-30T23:50:03+03:00 | 2026-10-29 | Мосбиржа ISS | UNVERIFIED |
| 7 | Ключевая ставка Банка России | 14.0 | percent per annum | — | 2026-07-27 | 2026-07-24 | Банк России | VERIFIED |
| 8 | RUONIA | 14.05 | percent per annum | -0.04 percentage points | 2026-10-29 | 2026-10-28 | Банк России | UNVERIFIED |
| 9 | Международные резервы РФ | 729.6 | billion USD | +6.4 billion USD | 2026-10-23 | 2026-10-16 | Банк России | UNVERIFIED |
| 10 | Доходность ОФЗ, 10 лет (кривая бескупонной доходности) | 16.56 | percent per annum | — | 2026-10-30T18:54:59+03:00 | — | Мосбиржа ISS | UNVERIFIED |
| 11 | Золото, Мосбиржа, рубли за грамм (GLDRUB_TOM) | 10149.5 | RUB per gram | -3.65 % | 2026-10-30T23:50:03+03:00 | 2026-10-29 | Мосбиржа ISS | VERIFIED |
| 12 | Инфляция, год к году (данные Росстата) | 6.35 | percent | +0.02 percentage points | 2026-09-30 | 2026-08-31 | Банк России (данные Росстата) | VERIFIED |
| 13 | Brent, нефть (спот EIA через FRED) | 123.1 | USD per barrel | -3.9182 % | 2026-10-27 | — | FRED / EIA (DCOILBRENTEU) | UNVERIFIED |
| 14 | S&P 500 | 7744 | index points | +0.2768 % | 2026-10-28 | — | FRED (SP500) | UNVERIFIED |
| 15 | Gold, спот XAU/USD | 3875.4 | USD per ounce | -0.2101 % | 2026-10-30T20:00:00Z | — | Twelve Data | UNVERIFIED |
| 16 | BTC/USD | 77398 | USD | +0.2506 % | 2026-10-31 | — | Kraken | UNVERIFIED |
| 17 | USD/EUR | 0.8951 | ratio | -0.3759 % | 2026-10-30 | — | ECB | UNVERIFIED |
| 18 | Шкала напряжённости мира (тональность деловых лент) | 24 | index 0-100 | — | 2026-10-31T14:00:02Z (newest article in the sample) | — | aggregated RSS feeds of the project | UNVERIFIED |

## Цепочка по каждому показателю

### 1. USD/RUB, официальный курс ЦБ (`usd-rub`)

- **Endpoint:** `https://www.cbr.ru/scripts/XML_dynamic.asp?date_req1=…&date_req2=…&VAL_NM_RQ=R01235`
- **Читаемое поле:** Record/Value (char code 840, nominal 1)
- **Функция:** `fetchCbrIndicator('USD')` — `api/russia-insights.js:174`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: VERIFIED.** The CBR daily document for 31.10.2026 returns 80.5573 — see 06_API_RESPONSES/cbr_fx_daily_2026-10-31.json

### 2. EUR/RUB, официальный курс ЦБ (`eur-rub`)

- **Endpoint:** `https://www.cbr.ru/scripts/XML_dynamic.asp?...&VAL_NM_RQ=R01239`
- **Читаемое поле:** Record/Value (char code 978)
- **Функция:** `fetchCbrIndicator('EUR')` — `api/russia-insights.js:174`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: VERIFIED.** CBR daily document for 31.10.2026 returns 89.6603

### 3. CNY/RUB, официальный курс ЦБ (`cny-rub-cbr`)

- **Endpoint:** `https://www.cbr.ru/scripts/XML_dynamic.asp?...&VAL_NM_RQ=R01375`
- **Читаемое поле:** Record/Value (char code 156)
- **Функция:** `fetchCbrIndicator('CNY')` — `api/russia-insights.js:174`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: да
- **Про резерв:** This tile is rendered only when the exchange CNY/RUB (cny-rub-moex) is missing: src/components/RussiaBusiness.tsx:712-721. It is a deliberate CBR fallback, not a silent replacement, and it carries its own provider label.
- **Статус: VERIFIED.** CBR daily document for 31.10.2026 returns 12.0873

### 4. IMOEX, индекс МосБиржи (`imoex`)

- **Endpoint:** `https://iss.moex.com/iss/engines/stock/markets/index/securities/IMOEX.json?iss.meta=off + https://iss.moex.com/iss/history/engines/stock/markets/index/securities/IMOEX.json`
- **Читаемое поле:** marketdata/CURRENTVALUE; history/CLOSE
- **Функция:** `fetchMoexIndex('IMOEX', …) + pickPreviousClose()` — `api/russia-insights.js:548, api/russia-insights.js:493`
- **Кэш/обновление:** 2026-10-31T17:46:35+03:00 (source SYSTIME)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: VERIFIED.** Independent ISS capture at 17:49:37 MSK returned 2511.36 with SYSTIME 2026-10-31 17:49:37 — the index is live and moving; see 06_API_RESPONSES/moex_imoex_quote.json. The change itself (0.09 %) was not recomputed against a second capture of the previous close; the history endpoint value 2509.26 for 30.10 appears in the history payload of the page and is consistent with 2511.43 (+0.086 %).

### 5. RGBI, индекс гособлигаций (`rgbi`)

- **Endpoint:** `https://iss.moex.com/iss/engines/stock/markets/index/securities/RGBI.json?iss.meta=off + history`
- **Читаемое поле:** marketdata/CURRENTVALUE; history/CLOSE
- **Функция:** `fetchMoexIndex('RGBI', …) + pickPreviousClose()` — `api/russia-insights.js:548, api/russia-insights.js:493`
- **Кэш/обновление:** 2026-10-31T17:46:31+03:00 (source SYSTIME)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** Not re-fetched from ISS during this audit; the previous session's capture (30.10 close 112.41) is consistent with +0.06 %, but no independent capture was taken for this pass.

### 6. CNY/RUB, юань на Мосбирже (CNYRUB_TOM) (`cny-rub-moex`)

- **Endpoint:** `https://iss.moex.com/iss/engines/currency/markets/selt/securities/CNYRUB_TOM.json?iss.meta=off + history`
- **Читаемое поле:** marketdata/LAST (CETS); history/CLOSE
- **Функция:** `fetchMoexCny() + fetchCurrencyHistory() + pickQuoteBase()` — `api/russia-insights.js:710, api/russia-insights.js:534, api/russia-insights.js:511`
- **Кэш/обновление:** 2026-10-30T23:50:03+03:00 (source SYSTIME)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** Method is the same as the verified gold tile (last trade vs previous session close of the same board). The exact CNYRUB_TOM history was not captured in this pass.

### 7. Ключевая ставка Банка России (`key-rate`)

- **Endpoint:** `https://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx (SOAP KeyRate)`
- **Читаемое поле:** KeyRate/KR/DT + Rate
- **Функция:** `fetchCbrKeyRate(), parseKeyRateXml()` — `api/russia-insights.js:288, api/russia-insights.js:220`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: VERIFIED.** The CBR page for 23–30.10.2026 shows 14,00 % for every day in the range, page last updated 30.10.2026 — value VERIFIED. The asOf date shown by the site (2026-07-27) is the day the rate took effect, not an observation date; that specific claim was not independently confirmed (UNVERIFIED). See 05_FRESHNESS_AUDIT.md.

### 8. RUONIA (`ruonia`)

- **Endpoint:** `https://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx (SOAP Ruonia)`
- **Читаемое поле:** Ro/RUONIA + DATE
- **Функция:** `fetchRuonia()` — `api/russia-insights.js:345, api/_shared/cbrRuonia.js`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** The CBR SOAP response was not captured during this audit (POST-only endpoint; the audit environment has no direct network access from the shell).

### 9. Международные резервы РФ (`reserves`)

- **Endpoint:** `https://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx (SOAP mrrf7DXML)`
- **Читаемое поле:** MRRF7D/Date + InternationalReserves (billion USD)
- **Функция:** `fetchReserves()` — `api/russia-insights.js:388, api/_shared/cbrReserves.js`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** Weekly series; the CBR SOAP response was not captured in this pass.

### 10. Доходность ОФЗ, 10 лет (кривая бескупонной доходности) (`ofz-10y`)

- **Endpoint:** `https://iss.moex.com/iss/engines/stock/zcyc.json?iss.meta=off`
- **Читаемое поле:** zcyc row where period = 10 years (column y10 / TENOR)
- **Функция:** `fetchMoexOfz10y(), extractCurve(), pickOfz10y()` — `api/russia-insights.js:420, api/russia-insights.js:274, api/russia-insights.js:253`
- **Кэш/обновление:** 2026-10-30T18:54:59+03:00
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** The zcyc payload was not captured; the 11 curve points shown on the page match the shape reported by ISS in the previous session.

### 11. Золото, Мосбиржа, рубли за грамм (GLDRUB_TOM) (`gold-moex`)

- **Endpoint:** `https://iss.moex.com/iss/engines/currency/markets/selt/securities/GLDRUB_TOM.json?iss.meta=off + https://iss.moex.com/iss/history/engines/currency/markets/selt/securities/GLDRUB_TOM.json`
- **Читаемое поле:** marketdata/LAST (board CETS); history/CLOSE (board CETS)
- **Функция:** `fetchMoexGold(), fetchCurrencyHistory(), pickQuoteBase()` — `api/russia-insights.js:596, api/russia-insights.js:534, api/russia-insights.js:511`
- **Кэш/обновление:** 2026-10-30T23:50:03+03:00 (source SYSTIME)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: VERIFIED.** Quote and history captured independently: LAST 10149.5 (CETS), CETS closes 29.10 = 10534, 30.10 = 10149.5. Recomputed change -3.6502 % matches the displayed -3.65 %. See 06_API_RESPONSES/moex_gldrub_tom_quote.json and moex_gldrub_tom_history.json.

### 12. Инфляция, год к году (данные Росстата) (`inflation`)

- **Endpoint:** `https://www.cbr.ru/hd_base/infl/ and https://www.cbr.ru/Queries/UniDbQuery/DownloadExcel/132934?FromDate=…&ToDate=…&posted=False`
- **Читаемое поле:** table column «Инфляция, г/г» for the last month row
- **Функция:** `fetchInflation()` — `api/russia-insights.js:665, api/_shared/cbrInflation.js`
- **Кэш/обновление:** 2026-10-31 (edge cache s-maxage=300)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: VERIFIED.** The CBR page captured during this audit lists 6,35 % for September 2026 and 6,33 % for August 2026, giving +0,02 п.п. See 06_API_RESPONSES/cbr_inflation_page_2026-10-31.txt.

### 13. Brent, нефть (спот EIA через FRED) (`brent`)

- **Endpoint:** `https://fred.stlouisfed.org/graph/fredgraph.csv?id=DCOILBRENTEU&cosd=…`
- **Читаемое поле:** CSV last row: observation_date + value
- **Функция:** `fetchBrent()` — `supabase/functions/update-assets/index.ts:250`
- **Кэш/обновление:** 2026-10-31 14:40:01 UTC (cached_assets.updated_at), as_of 2026-10-27
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** The FRED CSV was not captured in this pass. The 4-day gap between as_of (27.10) and the cache write (31.10) is a real publication lag of the EIA series; the UI prints the source date, and the daily passport repeats the same value for 28–30.10 with the note that no new observation arrived.

### 14. S&P 500 (`sp500`)

- **Endpoint:** `https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500&cosd=…`
- **Читаемое поле:** CSV last row
- **Функция:** `fetchSp500()` — `supabase/functions/update-assets/index.ts:236`
- **Кэш/обновление:** 2026-10-31 14:40:01 UTC, as_of 2026-10-28
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** FRED CSV not captured in this pass; FRED publishes this series with a lag, so as_of 28.10 on 31.10 is plausible but unconfirmed here.

### 15. Gold, спот XAU/USD (`gold`)

- **Endpoint:** `https://api.twelvedata.com/quote?symbol=XAU%2FUSD (requires API key in Supabase secrets)`
- **Читаемое поле:** quote.close, quote.percent_change, quote.timestamp
- **Функция:** `fetchGold()` — `supabase/functions/update-assets/index.ts:320`
- **Кэш/обновление:** 2026-10-31 14:40:01 UTC, as_of 2026-10-30 20:00 UTC
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** Requires the project's private API key; cannot be reproduced without it. Note this tile is spot USD/oz and is deliberately separate from the MOEX RUB/g tile — the site never converts one into the other.

### 16. BTC/USD (`btc`)

- **Endpoint:** `https://api.Kraken.com/0/public/OHLC?pair=XBTUSD&interval=1440`
- **Читаемое поле:** result.XXBTZUSD[-1][4] (close)
- **Функция:** `fetchBtc()` — `supabase/functions/update-assets/index.ts:289`
- **Кэш/обновление:** 2026-10-31 14:40:01 UTC, as_of 2026-10-31
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** Kraken OHLC not captured in this pass.

### 17. USD/EUR (`usd-eur`)

- **Endpoint:** `https://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml`
- **Читаемое поле:** Cube USD rate, inverted to USD/EUR
- **Функция:** `fetchUsdEur()` — `supabase/functions/update-assets/index.ts:264`
- **Кэш/обновление:** 2026-10-31 14:40:01 UTC, as_of 2026-10-30
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** ECB XML not captured in this pass. Note the inversion: ECB publishes EUR/USD, the tile shows USD/EUR — a derived number, computed as 1/rate.

### 18. Шкала напряжённости мира (тональность деловых лент) (`tension`)

- **Endpoint:** `Supabase REST cached_tension`
- **Читаемое поле:** value, label, news_count, sample_newest, history
- **Функция:** `supabase/functions/update-tension/index.ts` — `src/data/liveTension.ts, src/components/TensionScale.tsx`
- **Кэш/обновление:** 2026-10-31 14:45:01 UTC (cached_tension.updated_at)
- **Признаки:** хардкод: нет, резервное значение: нет
- **Статус: UNVERIFIED.** It is a derived sentiment index, not an official statistic. Its inputs (titles from 20+ RSS feeds) are real; the weighting and the classifier are the project's own model, so the number can only be checked for reproducibility, not against an official source.

## Что не удалось снять

- **CBR SOAP responses (RUONIA, reserves, key rate series)** — POST-only SOAP; the audit environment has no direct network from the shell and the HTTP tool sends GET. Статус: `UNVERIFIED`.
- **FRED CSVs (Brent, S&P 500), Kraken OHLC, ECB XML, Twelve Data quote, MOEX zcyc** — Not fetched in this pass to keep the package focused; all are reachable without keys except Twelve Data. Статус: `UNVERIFIED`.
- **Classifier outputs for individual headlines (sentiment, importance, confidence)** — Produced by the project's own classifier (Groq/Gemini), not an official source. Статус: `UNVERIFIED`.
