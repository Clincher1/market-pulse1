# Backend hardening: порядок деплоя (подготовлено 2026-10-22)

Статус на 2026-10-22: **подготовка завершена, код функций ещё не задеплоен**.
По отчёту владельца секрет уже создан в Vault, добавлен в Edge Function Secrets,
а все четыре pg_cron-задачи уже отправляют `x-cron-secret`. Поэтому шаги 1–3 ниже
уже выполнены; остался деплой кода и проверка. Коннектор Supabase в Arena 22.10
вернул Authentication failed (401), поэтому автоматический деплой из чата временно
недоступен до повторной аутентификации коннектора.

## Что подготовлено

| Артефакт | Что делает |
|---|---|
| `supabase/functions/update-assets/index.ts` | Добавлена проверка `isAuthorizedCron` в начале обработчика |
| `supabase/functions/update-tension/index.ts` | Та же проверка + консервативная дедупликация выборки |
| `supabase/functions/update-forecasts/index.ts` | Та же проверка + консервативная дедупликация сигналов |
| `supabase/functions/proxy/index.ts` | Заглушка **410 Gone** вместо публичного proxy |
| `supabase/sql/2026-10-22_cron_secret_hardening.sql` | Пошаговый SQL: секрет в Vault → обновление pg_cron → проверка |
| `supabase/functions/update-news/CRON_AUTH_PATCH.md` | Точный патч для минифицированного кода `update-news` (полного исходника локально нет) |

Проверка принимает **либо** `Authorization: Bearer <service_role>`, **либо** заголовок
`x-cron-secret`, равный секрету функции `CRON_SECRET`. Все остальные вызовы получают **401**.
Сравнение секрета — constant-time.

## ⚠️ Порядок (нарушать нельзя)

1. ✅ **STEP 0–1 из SQL выполнен владельцем**: текущие `cron.job` посмотрены,
   секрет `cron_secret` создан в Vault.
2. ✅ **Секрет скопирован владельцем** в Dashboard → Edge Functions → Secrets
   как `CRON_SECRET`. Никому его не отправлять, в git не класть.
3. ✅ **STEP 3 выполнен владельцем**: четыре cron-задачи отправляют `x-cron-secret`
   (проверено по `cron.job`). Старый код функций заголовок пока игнорирует.
4. ⏳ **Задеплоить три пропатченные функции** (`update-assets`, `update-tension`,
   `update-forecasts`), пропатчить `update-news` по `CRON_AUTH_PATCH.md` и удалить
   `proxy` в дашборде (или задеплоить заглушку 410).
5. ⏳ **STEP 5 из SQL**: проверить, что cron-запуски успешны; ручной вызов без секрета → 401,
   вызов cron с секретом → 200.

Если шаг 4 сделать раньше шага 3, cron начнёт получать 401 и кэши перестанут обновляться
(сайт продолжит работать на старых данных). Лечение — просто доделать шаг 3.

## update-news

Полного исходника в репозитории нет, а задеплоенный код виден в Supabase в
минифицированном виде. Для него подготовлен отдельный точный патч:
`supabase/functions/update-news/CRON_AUTH_PATCH.md`.

Он вставляется первым оператором обработчика, принимает service-role bearer
или `x-cron-secret`, сравнивает секрет в constant-time и возвращает 401 до
любого сбора новостей и вызова Groq. Восстанавливать весь `update-news` из
минифицированного кода ради одной проверки не нужно и рискованнее.

До деплоя этого патча `update-news` остаётся публично вызываемой — это
известный остаточный риск расхода квоты Groq.

## Что сознательно НЕ включено

- **Расписание V2 shadow** лежит в том же SQL (Part B), но закомментировано:
  по плану сначала малые батчи классификаций и ручной аудит качества, потом cron.
- `verify_jwt` у legacy-функций не трогаем: защита делается в коде, чтобы pg_net
  мог ходить без JWT, а авторизацию давал `x-cron-secret`.
- Удаление дубля секрета `SERVICE_KEY` — после того, как убедимся, что все функции
  читают `SUPABASE_SERVICE_ROLE_KEY` (отдельная маленькая задача этапа 5).

## Live completion — 2026-10-22 evening (Supabase connector)

Reconnect verified (credential valid, project ACTIVE_HEALTHY). The following
were deployed and runtime-tested with unauthenticated 401 + authorized pg_net
calls using the Vault `cron_secret` (values never printed):

- `update-tension` -> v13 (cron guard + server-side dedupe). Authorized test
  returned HTTP 200.
- `update-forecasts` -> v11 (cron guard + dedupe). Authorized test HTTP 200.
- `update-assets` -> v15 (cron guard; canonical env-only Twelve writer).
  Authorized test HTTP 200 and republished all five assets.
- `proxy` -> v20 hardened GET-only RSS helper. The old public POST branch
  that injected the server Groq key was removed. POST now 405, disallowed
  hosts 403, allowed RSS 200. Do not delete: `update-news-v2` keeps it as a
  fetch fallback.
- Legacy `update-news` could not be safely patched from its truncated ESZIP
  body, and gateway `verify_jwt=true` was proven insufficient because the
  public publishable key still invoked it. It was replaced by
  `update-news-v2` (in-code cron guard, dedupe before Groq, clamped output,
  stop on Groq 429). pg_cron job 2 now calls `update-news-v2`; the old
  `update-news` slug and the temporary dispatcher were deleted (404).
- `update-gdelt` was inspected: already a no-op Stage-1 retirement stub
  (no writes, no provider spend). Left as is.
- Groq operational finding: the 120B model hit its 200k tokens/day cap
  (429) during verification, largely because the old news writer re-analyzed
  duplicates every run. `update-news-v2` dedupes by URL before Groq and
  stops after the first 429. Until tokens roll off, news insertion can
  legitimately return `updated: 0` with `groq_error` set.

Uploading `supabase/functions/**` to GitHub remains provenance only; the
functions above are already live in Supabase.
