# 08. Система обновлений

Сборка `e4939ae`. Всё, что ниже, снято из работающей системы: расписание — из таблицы `cron.job` боевой базы (коннектор Supabase, 31.10.2026), код — из репозитория, кэш-заголовки — из ответов прод-API.

---

## 1. Расписание (боевая база, `cron.job`)

| jobid | Имя | Cron | Что запускает |
|---|---|---|---|
| 2 | `update-news-every-15-min` | `*/15 * * * *` | `update-news-v2` — сбор лент, дедупликация, классификация |
| 3 | `update-tension-every-15-min` | `*/15 * * * *` | `update-tension` — индекс напряжённости |
| 7 | `update-assets-every-5-min` | `*/5 * * * *` | `update-assets` — 5 мировых активов в `cached_assets` |
| 11 | `update-forecasts-every-15-min` | `*/15 * * * *` | `update-forecasts` — карточки прогнозов для UI |
| 12 | `shadow-ingest-v2` | `5,35 * * * *` | `ingest-news-v2-shadow` |
| 13 | `shadow-cluster-v2` | `12,42 * * * *` | `cluster-news-v2-shadow` |
| 14 | `shadow-classify-v3` | `20 * * * *` | `classify-events-v2-shadow` |
| 15 | `shadow-prices-v2` | `20 5,17 * * *` | `update-prices-v2-shadow` |
| 16 | `shadow-evaluate-events-v2` | `35 5,17 * * *` | `evaluate-event-impacts-v2-shadow` |
| 17 | `shadow-write-forecasts-v2` | `45 5 * * *` | `write-forecasts-v2-shadow` |
| 18 | `shadow-evaluate-forecasts-v2` | `50 5,17 * * *` | `evaluate-forecasts-v2-shadow` — исходы и Брайер |
| 19 | `morning-snapshot` | `0 4 * * *` | `snapshot-morning` — паспорт дня в 07:00 МСК |
| 20 | `selfcheck-hourly` | `25 * * * *` | `selfcheck` — 20 проверок в `site_health` |
| 21 | `site-health-prune` | `40 3 * * *` | очистка истории проверок |

Все 14 задач активны (`active = true`). Время в cron — UTC; `0 4 * * *` = 07:00 МСК, и паспорт подписан «зафиксировано в 07:00 МСК».

## 2. Serverless-функции Vercel

| Файл | Назначение | Лимиты | Кэш ответа |
|---|---|---|---|
| `api/russia-insights.js` | 12 индикаторов + 18 заголовков | `maxDuration: 30` (`vercel.json`) | без ошибок `public, s-maxage=300, stale-while-revalidate=900`; с ошибками `s-maxage=60, swr=120` |
| `api/russia-history.js` | 5 рядов за 92 дня | `maxDuration: 30` | `public, s-maxage=1800, swr=900` |
| `api/brief-image.js` | картинка брифинга (satori + resvg) | `maxDuration: 30`, `includeFiles: api/assets/**` | — |

Сайт — статическая сборка (`vite build`) на CDN Vercel; данные приходят клиентскими запросами к этим функциям и к Supabase. **SSR/ISR/`revalidate` не используются** — в `vite.config.ts` нет ни `ssr`, ни `build.ssr`, ни пререндера.
`stale-while-revalidate` означает: в пределах указанного окна Vercel может отдать устаревший ответ, одновременно обновляя его в фоне. Для российского контура это окно 300 с (900 с при отсутствии ошибок), для истории — 1800 с.

## 3. Supabase Edge Functions (Deno)

Тип-чек всех функций — в CI: `cd supabase/functions && deno check */index.ts _shared/*.ts`.

| Функция | Роль | Что пишет |
|---|---|---|
| `update-assets` | цены мировых активов | `cached_assets` (+ `asset_price_history_v1` через отдельный путь) |
| `update-tension` | индекс напряжённости | `cached_tension`, `tension_history` |
| `update-news-v2` | ленты | `cached_news` |

Реестр лент проверен в боевой БД 31.10.2026: таблица `news_sources_v2` содержит **24 источника, из них 20 включены** (выключены `dw-business`, `guardian-business`, `rbc-full`, `TASS`; причину выключения ни репозиторий, ни журнал здоровья не фиксируют — это **UNVERIFIED**, а не «не отдают RSS»). Полный список с ролями, языком, весом доверия и предельным возрастом материала — в `EVIDENCE/news_sources_v2.txt`.

За последние 24 часа все 20 включённых лент опрошены и дали материалы: журнал `news_source_health_v2` (8 025 строк с 21.10) фиксирует по каждой 43–48 успешных запусков из 48, кроме `reuters-google-business` — 7 из 48 (Google News отвечает 503 в ~85 % запусков) при 140 принятых кандидатах. Разбор — `EVIDENCE/news_source_health_24h.txt`.
| `update-forecasts` | карточки для UI | `cached_forecasts` |
| `write-forecasts-v2-shadow` | журнал прогнозов | `market_forecasts_v2`, `forecast_outcomes_v2` |
| `evaluate-forecasts-v2-shadow` | исходы и Брайер | `forecast_outcomes_v2` |
| `snapshot-morning` | паспорт дня | `daily_snapshots` |
| `selfcheck` | самопроверка | `site_health` |
| `source-probe`, `price-probe-v2-shadow`, `update-prices-v2-shadow`, `run-shadow-pipeline` и др. | вспомогательные пробы и теневой конвейер | диагностические таблицы |
| `proxy` | прокси к внешним источникам для теневого конвейера | — |

Все секреты функции читают из окружения Supabase (`SUPABASE_SERVICE_ROLE_KEY`, ключи источников). В репозитории секретов нет — см. `SOURCE_CODE/.env.example` и `EVIDENCE/secret_scan.txt`.

## 4. Деплой и контроль

- **CI:** `.github/workflows/deploy-functions.yml` («Verify and deploy») на push в `main` по путям `api/**`, `src/**`, `supabase/functions/**`, `tests/**`, `vercel.json`: `deno check` → `npm ci` → типы → тесты → сборка → деплой функций в Supabase. Красный прогон сам заводит задачу в Linear.
- **Прод-деплой сайта:** Vercel на тот же push (preview на PR, production на `main`).
- **Коммиты только от `Clincher1 <…@users.noreply.github.com>`** — иначе Vercel блокирует деплой (правило проекта, зафиксировано в истории).
- **Мониторинг:** серверный Sentry (`supabase/functions/_shared/observability.ts`), проверка `sentry` в `selfcheck` отправляет пробное событие раз в час и подтверждает приём. Браузерного SDK нет, счётчиков и аналитики нет — проверка `no_telemetry` ищет 11 признаков в разметке (последний прогон: ни одного).

## 5. Может ли сайт показать старые цифры как новые?

Разбор по слоям:

| Слой | Риск | Что мешает |
|---|---|---|
| `api/russia-insights` | Vercel отдаёт ответ из edge-кэша до 5 минут | это кэш **ответа**, а не подмена даты: внутри ответа стоит `asOf` источника; 5 минут не превращают пятничное в субботнее |
| `api/russia-history` | кэш 30 минут | тот же принцип; точки идут с датами |
| `cached_assets` | Supabase отдаёт строку, записанную 5 минут назад, но с наблюдением от 27.10 (Brent) | `as_of` печатается на плитке; `observationLabel()` показывает дату источника, а не время записи |
| `cached_tension` | при сбое обновления остаётся прошлое значение | плашка «Показано последнее успешное значение от <время>» |
| `daily_snapshots` | не перезаписывается | `resolution=ignore-duplicates`; «повторный запуск не перезаписывает» |
| `forecast_outcomes_v2` | пересчёт задним числом | прежние значения сохраняются в `raw`, строки не удаляются (правило проекта, миграция `20261029120000_rescore_outcomes_from_series_base.sql`) |

**Вывод:** механизма, который меняет дату наблюдения на «сейчас», в коде нет. Есть два честно подписанных случая, когда число на экране старше сегодняшнего дня: публикационный лаг FRED (Brent, S&P 500) и месячная/недельная статистика ЦБ. Оба проговариваются в подписи плитки.

**Чего автоматика не ловит:** `selfcheck` проверяет свежесть только `cached_assets` (45 минут по `updated_at`) и новостей. Дата наблюдения (`as_of`) автоматически не проверяется, поэтому «Brent от 27.10» остаётся зелёным. Это ограничение зафиксировано и в `05_FRESHNESS_AUDIT.md`.

## 6. Логи последних обновлений

| Что | Значение | Источник |
|---|---|---|
| `cached_assets.updated_at` | 2026-10-31 14:40:01 UTC (все 5 строк) | таблица БД |
| `cached_tension.updated_at` | 2026-10-31 14:45:01 UTC, `sample_newest` 14:00:02 UTC | таблица БД |
| `site_health` последний прогон | 2026-10-31 14:25:01 UTC, 20/20 `ok` | таблица БД |
| Деплой прод-сборки | CI `41211489723` — success, коммит `e4939ae` | GitHub Actions |
